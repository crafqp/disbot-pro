# Discord Bot Design Guidelines

## Project Context
This is a **Discord bot application**, not a traditional web interface. These guidelines focus on how the bot communicates within Discord and the aesthetic choices it makes when building servers.

---

## Bot Communication Design

### Message Structure
- **Embed-Based Responses**: All bot responses use Discord embeds for professional appearance
- **Color Coding**: 
  - Questions/Prompts: Blue (#5865F2 - Discord Blurple)
  - Confirmations: Green (#57F287)
  - Warnings: Yellow (#FEE75C)
  - Errors: Red (#ED4245)
  - Information: Gray (#99AAB5)

### Questionnaire UX
- **Progressive Disclosure**: Ask 15-20 questions in logical groups
  1. Core Purpose (3-4 questions): Server type, target audience, community size
  2. Structure Preferences (4-5 questions): Category organization, channel types, hierarchy
  3. Design & Aesthetics (3-4 questions): Theme, color preferences, emoji style, naming conventions
  4. Functionality (3-4 questions): Moderation needs, ticket system, special features
  5. Permissions & Access (2-3 questions): Role structure, privacy levels, member capabilities

- **Question Format**: Mix of buttons, dropdowns, and open-ended text responses
- **Visual Progress**: Show "Question 3 of 18" in embed footers
- **Context**: Each question includes brief explanation of why it matters

---

## Server Design System

### Role Color Coordination
Gemini analyzes theme preference and creates cohesive color palette:
- **Professional/Corporate**: Blues, grays, subtle accents
- **Gaming/Creative**: Vibrant, high-contrast colors
- **Community/Social**: Warm, inviting tones
- **Educational**: Clean, organized palette with distinct hierarchy

### Channel Naming Conventions
Based on user's aesthetic preference:
- **Minimalist**: lowercase-with-dashes, simple names
- **Professional**: Title Case With Emojis
- **Casual**: friendly names with personality
- **Technical**: Organized-With-Prefixes-By-Category

### Emoji Strategy
- **Consistent Theme**: All category emojis follow same style (solid colors, symbols, or themed icons)
- **Visual Hierarchy**: Important categories get distinctive emojis
- **Accessibility**: Emojis complement, don't replace, clear text labels

---

## Server Structure Organization

### Category Ordering (Top to Bottom)
1. Welcome/Info (rules, announcements, getting-started)
2. Main Activity Channels (purpose-specific)
3. Community/Social Channels
4. Support/Help Desk (with ticket system)
5. Moderation (staff-only, hidden from members)
6. Archive/Utility (hidden or collapsed)

### Channel Permission Logic
- **Read-Only Channels**: Announcements, rules, info → Only admins can send
- **General Discussion**: Default member access
- **Specialized Channels**: Role-specific permissions based on purpose
- **Staff Channels**: Completely hidden from non-staff
- **Ticket Channels**: Dynamic permissions per ticket

---

## Functional Systems Design

### Ticket System
- **Support Category**: Contains ticket-creation channel + active tickets
- **Embed Interface**: Professional ticket creation with dropdown for issue types
- **Auto-Naming**: "ticket-{username}-{number}" format
- **Permissions**: Ticket creator + staff only

### Moderation Tools
- **Mod Logs Channel**: All actions logged with embeds (color-coded by severity)
- **Mod Discussion**: Private staff coordination
- **Reports Channel**: Member reports collected and formatted

---

## Confirmation Preview Design
Before creating server, show comprehensive embed displaying:
- Category list with all channels
- Permission summary for each channel
- Role hierarchy with colors
- Functional systems included
- Design theme applied
- "✅ Approve" and "❌ Cancel" buttons

---

## Post-Creation Modification UX
- **Natural Language Input**: "Make the announcements channel read-only for everyone except admins"
- **Gemini Processing**: Understands intent and makes precise changes
- **Change Confirmation**: Shows before/after in embed format
- **Undo Capability**: Track recent changes, allow rollback

---

## Visual Consistency Principles
1. **Coherent Theme**: Every element reinforces the chosen aesthetic
2. **Logical Flow**: Server structure feels intuitive and well-organized
3. **Professional Polish**: No default Discord channels, everything intentional
4. **Scalable Design**: Works for small communities and large servers alike