# Discord Server Builder Bot

A Gemini-powered Discord bot that creates fully configured, professional Discord servers through an intelligent interview process.

## Overview

This bot conducts a comprehensive 15+ question interview covering server purpose, structure preferences, design aesthetics, functionality requirements, and permissions. Using Gemini AI, it analyzes responses to intelligently design server layout, role hierarchies, channel permissions, naming conventions, and visual styling.

## Features

### Core Features
- **Interactive Questionnaire System**: 15+ questions with buttons, dropdowns, and text inputs
- **AI-Powered Design**: Gemini AI generates intelligent server structures
- **Automated Server Building**: Creates channels, categories, roles with proper permissions
- **Ticket System**: Built-in support ticket system with private channels
- **Moderation Tools**: Staff-only areas, logging channels, report systems
- **Post-Creation Modifications**: Natural language commands to modify server after creation

### Moderation & AutoMod
- **Warning System**: Issue warnings with escalation tracking (3 warnings = mute, 5 = kick, 7 = ban)
- **Logging System**: Automatic logging of all moderation actions to a configured channel
- **Anti-Spam Detection**: Detects and removes spam messages automatically
- **Bad Word Filter**: Customizable word filter with add/remove/list/clear commands
- **Raid Protection**: Detects mass joins and can auto-lockdown the server

### Additional Features
- **Template Library**: 5 pre-built templates (Gaming, Business, Community, Education, Creative)
- **Welcome Messages**: Auto-activates after bot joins, configurable welcome messages for new members
- **Auto-Roles**: Automatically assign Member role to new members
- **Reaction Roles**: Role assignment through message reactions
- **XP/Leveling System**: Track member activity with levels and leaderboards

## Commands

| Command | Description |
|---------|-------------|
| `!setup` | Start the full server setup questionnaire |
| `!templates` | Quick setup using pre-made templates |
| `!welcome` | Configure welcome messages and auto-roles |
| `!reactionroles` | Set up reaction-based role assignment |
| `!modify <request>` | Make changes using natural language |
| `!preview` | View current server design before applying |
| `!help` | Show help message with all commands |
| `!botcontrol` | Access bot settings panel (Admin) |
| `!warnings @user` | View a user's warning history (Staff) |
| `!badwords add/remove/list/clear` | Manage word filter (Admin) |
| `!level` / `!rank` | View your level and XP |
| `!leaderboard` | View the server leaderboard |
| `!report` | Report a rule violation to moderators |
| `!ban @user [reason]` | Ban a member |
| `!kick @user [reason]` | Kick a member |
| `!mute @user [minutes] [reason]` | Timeout a member |
| `!warn @user [reason]` | Issue a warning |
| `!clear [amount]` | Delete messages (1-100) |
| `!slowmode [seconds]` | Set channel slowmode |
| `!lock` / `!unlock` | Lock/unlock channel |

## Architecture

### Backend (Express.js + Discord.js)
- `server/discord/bot.ts` - Main Discord bot logic
- `server/gemini.ts` - Gemini AI integration for design generation
- `server/routes.ts` - API routes for dashboard
- `server/storage.ts` - Data storage interface

### Frontend (React + Vite)
- `client/src/pages/Home.tsx` - Dashboard showing bot status
- Uses shadcn/ui components with Tailwind CSS

### Shared
- `shared/schema.ts` - Drizzle ORM schema definitions

## Environment Variables

Required secrets:
- `DISCORD_BOT_TOKEN` - Discord bot token from Developer Portal
- `GEMINI_API_KEY` - Google Gemini API key

## Bot Permissions

The bot requires Administrator permission for full functionality:
- Create/delete channels and categories
- Create/manage roles
- Manage permissions
- Send messages and embeds
- Manage reactions

## Server Templates

### Gaming Community
Perfect for gaming communities, streamers, and esports teams. Includes LFG channels, gaming voice channels, and vibrant design.

### Business/Professional
Ideal for companies and professional teams. Clean design, departmental organization, verification system.

### General Community
Great for friend groups and social spaces. Warm colors, friendly atmosphere, open access.

### Educational/Study Group
Perfect for study groups and learning communities. Subject-specific channels, study session voice channels.

### Creative/Artist Community
For artists, designers, and creative individuals. Gallery channels, critique sections, artistic design.

## Development

### Replit Setup (Completed - December 5, 2025)
This project is configured to run on Replit:
- **Node.js**: Version 20.19.3
- **Database**: PostgreSQL database available (DATABASE_URL environment variable set)
- **Secrets**: DISCORD_BOT_TOKEN and GEMINI_API_KEY configured in Replit Secrets
- **Workflow**: "Start application" workflow configured to run `npm run dev` on port 5000 with webview
- **Vite Configuration**: Dev server configured with `allowedHosts: true` for Replit proxy (see server/vite.ts)
- **Deployment**: VM deployment type configured with build command `npm run build` and run command `npm start`

### Running Locally
The app starts automatically with the workflow. Alternatively, run:
```bash
npm run dev
```

### Testing Bot
1. Invite the bot to a test server using the invite link from the dashboard
2. Type `!setup` to start the questionnaire
3. Or type `!templates` to use a pre-built template

### Deployment
The project is configured for VM deployment which keeps the Discord bot running 24/7:
- Build command: `npm run build`
- Run command: `npm start`
- Deployment type: VM (required for stateful Discord bot)

## Recent Changes

### December 2025
- **Fixed channel protection during server cleanup** - Bot now properly preserves the setup channel, system channel, and their parent categories during server building
- **Fixed interaction error handling** - Resolved crashes from duplicate Discord API responses using proper defer/reply/editReply patterns
- **Added modification apply/cancel handlers** - Complete flow for applying or canceling pending server modifications
- **Improved AI design quality** - Reduced excessive emojis (max 2 per category), better formatting, added stage channel support for voice-heavy servers
- **Enhanced ticket system** - Better error handling, permission checks, auto-creation of support category
- **Fixed TypeScript configuration** - Added ES2015+ iteration support and proper discord.js type handling

### Earlier Updates
- Added 5 server templates for quick setup
- Implemented welcome message system with auto-roles
- Added reaction roles for self-assignable roles
- Fixed partial reaction handling for persistent role assignments
- Enhanced help command with all available features

## Known TypeScript Notes

The codebase has some discord.js type compatibility warnings that don't affect runtime behavior. These are due to discord.js's complex generic types for ActionRowBuilder and component types. The bot runs successfully despite these type warnings.
