// Gemini AI Integration for Discord Server Builder
// Following the javascript_gemini blueprint

import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

// Server structure generation based on questionnaire responses
export interface ServerDesign {
  serverName: string;
  description: string;
  theme: {
    style: "professional" | "gaming" | "creative" | "educational" | "community" | "custom";
    colorScheme: string[];
    emojiStyle: "minimal" | "colorful" | "themed" | "unicode";
    namingConvention: "lowercase" | "titlecase" | "casual" | "technical";
  };
  roles: RoleConfig[];
  categories: CategoryConfig[];
  ticketSystem: TicketSystemConfig | null;
  moderationTools: ModerationConfig;
}

export interface RoleConfig {
  name: string;
  color: string;
  permissions: string[];
  position: number;
  mentionable: boolean;
  hoist: boolean;
  description: string;
}

export interface ChannelConfig {
  name: string;
  type: "text" | "voice" | "announcement" | "forum" | "stage";
  topic: string;
  position: number;
  permissions: ChannelPermission[];
  slowmode?: number;
  nsfw?: boolean;
  emoji?: string;
}

export interface ChannelPermission {
  role: string;
  allow: string[];
  deny: string[];
}

export interface CategoryConfig {
  name: string;
  position: number;
  emoji?: string;
  channels: ChannelConfig[];
  permissions: ChannelPermission[];
}

export interface TicketSystemConfig {
  enabled: boolean;
  categoryName: string;
  supportRoles: string[];
  ticketTypes: string[];
  welcomeMessage: string;
}

export interface ModerationConfig {
  enabled: boolean;
  logChannel: boolean;
  modDiscussion: boolean;
  reportsChannel: boolean;
  automod: boolean;
}

export interface QuestionnaireResponses {
  serverPurpose: string;
  targetAudience: string;
  communitySize: string;
  primaryActivities: string[];
  channelTypes: string[];
  roleHierarchy: string;
  moderationLevel: string;
  designTheme: string;
  colorPreferences: string;
  emojiStyle: string;
  namingStyle: string;
  ticketSystemNeeded: boolean;
  specialFeatures: string[];
  accessLevels: string;
  additionalNotes: string;
}

export async function generateServerDesign(responses: QuestionnaireResponses): Promise<ServerDesign> {
  const systemPrompt = `You are an expert Discord server architect. Based on the user's questionnaire responses, generate a comprehensive server design with:

1. Appropriate role hierarchy with proper permissions and colors that match the theme
2. Logically organized categories and channels with proper ordering (info/welcome first, then main activity, then community, then support, then moderation last)
3. Intelligent permission configurations (read-only for announcements, discussion for general, restricted for staff)
4. Consistent visual design (role colors, channel emojis, naming conventions)
5. Ticket system configuration if requested
6. Moderation tools setup

CRITICAL DESIGN RULES:
- Category and channel names should follow the user's preferred naming convention
- Role colors should form a cohesive palette matching the theme (use hex colors like #5865F2)
- Permissions should be secure by default (deny @everyone where appropriate)
- Order channels logically within categories (most important first)
- Staff/mod channels should be completely hidden from members

EMOJI USAGE RULES (VERY IMPORTANT):
- If emojiStyle is "minimal": Use NO emojis at all. Leave emoji fields as null.
- If emojiStyle is "unicode": Use ONLY 1 simple unicode emoji per category (like 📢 💬 🔊), and NO emojis on individual channels.
- If emojiStyle is "colorful" or "themed": Use 1 emoji per category and optionally 1 per channel, but keep it consistent.
- NEVER use multiple emojis together (like "🎮✨🎯").
- NEVER use emojis that look cluttered or random.
- When in doubt, use FEWER emojis rather than more.

CHANNEL STRUCTURE RULES:
- Include at least one "stage" type channel in voice categories for events/presentations.
- For gaming/community servers, include voice channels with logical names (not excessive emojis).
- Keep channel names SHORT and clear (max 25 characters).
- Use consistent naming: either all-lowercase-with-dashes OR Title-Case, not mixed.

ROLE HIERARCHY RULES:
- Maximum 8-10 roles for most servers (don't over-complicate).
- Ensure proper position ordering (higher number = higher in hierarchy).
- Use readable role names without excessive symbols.

Return a valid JSON object matching this exact structure:
{
  "serverName": "string",
  "description": "string", 
  "theme": {
    "style": "professional|gaming|creative|educational|community|custom",
    "colorScheme": ["#hex1", "#hex2", ...],
    "emojiStyle": "minimal|colorful|themed|unicode",
    "namingConvention": "lowercase|titlecase|casual|technical"
  },
  "roles": [
    {
      "name": "string",
      "color": "#hexcolor",
      "permissions": ["permission1", "permission2"],
      "position": number,
      "mentionable": boolean,
      "hoist": boolean,
      "description": "string"
    }
  ],
  "categories": [
    {
      "name": "string",
      "position": number,
      "emoji": "emoji or null",
      "channels": [
        {
          "name": "string",
          "type": "text|voice|announcement|forum|stage",
          "topic": "string",
          "position": number,
          "permissions": [
            {"role": "roleName", "allow": ["perm1"], "deny": ["perm2"]}
          ],
          "slowmode": number or null,
          "nsfw": boolean,
          "emoji": "emoji or null"
        }
      ],
      "permissions": []
    }
  ],
  "ticketSystem": {
    "enabled": boolean,
    "categoryName": "string",
    "supportRoles": ["role1"],
    "ticketTypes": ["type1", "type2"],
    "welcomeMessage": "string"
  } or null,
  "moderationTools": {
    "enabled": boolean,
    "logChannel": boolean,
    "modDiscussion": boolean,
    "reportsChannel": boolean,
    "automod": boolean
  }
}`;

  const userPrompt = `Generate a Discord server design based on these questionnaire responses:

Server Purpose: ${responses.serverPurpose}
Target Audience: ${responses.targetAudience}
Expected Community Size: ${responses.communitySize}
Primary Activities: ${responses.primaryActivities.join(", ")}
Desired Channel Types: ${responses.channelTypes.join(", ")}
Role Hierarchy Preferences: ${responses.roleHierarchy}
Moderation Level: ${responses.moderationLevel}
Design Theme: ${responses.designTheme}
Color Preferences: ${responses.colorPreferences}
Emoji Style: ${responses.emojiStyle}
Naming Convention: ${responses.namingStyle}
Ticket System Needed: ${responses.ticketSystemNeeded ? "Yes" : "No"}
Special Features Requested: ${responses.specialFeatures.join(", ")}
Access Level Structure: ${responses.accessLevels}
Additional Notes: ${responses.additionalNotes}

Create a complete, professional server structure that perfectly matches these preferences.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
      },
      contents: userPrompt,
    });

    const rawJson = response.text;
    if (rawJson) {
      return JSON.parse(rawJson) as ServerDesign;
    }
    throw new Error("Empty response from Gemini");
  } catch (error) {
    console.error("Gemini server design generation failed:", error);
    throw new Error(`Failed to generate server design: ${error}`);
  }
}

export async function processModificationRequest(
  currentDesign: ServerDesign,
  userRequest: string
): Promise<{ changes: ModificationChange[]; explanation: string }> {
  const systemPrompt = `You are a Discord server modification expert. The user wants to make changes to their existing server design. 
Analyze their natural language request and generate specific, actionable changes.

Return JSON in this format:
{
  "changes": [
    {
      "type": "add_channel|remove_channel|modify_channel|add_role|remove_role|modify_role|add_category|remove_category|modify_permissions",
      "target": "name of the thing being modified",
      "category": "category name if applicable",
      "details": { specific changes as key-value pairs }
    }
  ],
  "explanation": "Human-readable summary of what changes will be made"
}`;

  const userPrompt = `Current server design:
${JSON.stringify(currentDesign, null, 2)}

User's modification request: "${userRequest}"

Generate the specific changes needed to fulfill this request.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
      },
      contents: userPrompt,
    });

    const rawJson = response.text;
    if (rawJson) {
      return JSON.parse(rawJson);
    }
    throw new Error("Empty response from Gemini");
  } catch (error) {
    console.error("Modification processing failed:", error);
    throw new Error(`Failed to process modification: ${error}`);
  }
}

export interface ModificationChange {
  type: string;
  target: string;
  category?: string;
  details: Record<string, any>;
}

export async function analyzeServerPurpose(description: string): Promise<{
  suggestedTheme: string;
  suggestedChannels: string[];
  suggestedRoles: string[];
  followUpQuestions: string[];
}> {
  const systemPrompt = `You are an expert Discord server consultant. Based on the user's description of their server purpose, provide intelligent suggestions and follow-up questions to help them build the perfect server.

Return JSON:
{
  "suggestedTheme": "professional|gaming|creative|educational|community",
  "suggestedChannels": ["channel suggestions based on purpose"],
  "suggestedRoles": ["role suggestions based on purpose"],
  "followUpQuestions": ["clarifying questions to better understand needs"]
}`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
      },
      contents: `Server purpose description: "${description}"`,
    });

    const rawJson = response.text;
    if (rawJson) {
      return JSON.parse(rawJson);
    }
    throw new Error("Empty response");
  } catch (error) {
    console.error("Purpose analysis failed:", error);
    throw new Error(`Failed to analyze purpose: ${error}`);
  }
}

export async function generateChannelTopics(
  channelName: string,
  serverPurpose: string,
  theme: string
): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Generate a brief, professional channel topic/description (max 100 characters) for a Discord channel named "${channelName}" in a ${theme} themed server focused on: ${serverPurpose}. Return only the topic text, no quotes or extra formatting.`,
    });

    return response.text?.trim() || `Welcome to ${channelName}`;
  } catch (error) {
    return `Welcome to ${channelName}`;
  }
}

export async function generateWelcomeMessage(
  serverDesign: ServerDesign,
  serverPurpose: string
): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Generate a welcoming, friendly message for new members joining a Discord server. 
Server name: ${serverDesign.serverName}
Purpose: ${serverPurpose}
Theme: ${serverDesign.theme.style}
Key channels they should check out: ${serverDesign.categories.slice(0, 2).map(c => c.channels.slice(0, 2).map(ch => ch.name).join(", ")).join(", ")}

Keep it under 500 characters, friendly but professional. Include a brief overview of what the server is about and guide them to important channels. Do not use emojis.`,
    });

    return response.text?.trim() || "Welcome to the server! We're glad to have you here.";
  } catch (error) {
    return "Welcome to the server! We're glad to have you here. Check out our channels and introduce yourself!";
  }
}

export async function generateServerRules(
  serverPurpose: string,
  moderationLevel: string,
  theme: string
): Promise<string[]> {
  const systemPrompt = `Generate appropriate server rules for a Discord server. Return a JSON array of rule strings.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
      },
      contents: `Server purpose: ${serverPurpose}
Moderation level: ${moderationLevel}
Theme: ${theme}

Generate 6-10 appropriate rules that match the server's tone and purpose.`,
    });

    const rawJson = response.text;
    if (rawJson) {
      return JSON.parse(rawJson);
    }
    return ["Be respectful to all members", "No spam or self-promotion", "Follow Discord's Terms of Service"];
  } catch (error) {
    return ["Be respectful to all members", "No spam or self-promotion", "Follow Discord's Terms of Service"];
  }
}
