import type { Express } from "express";
import { createServer, type Server } from "http";
import { createDiscordBot } from "./discord/bot";

let discordClient: any = null;
let botStatus: "offline" | "connecting" | "online" | "error" = "offline";
let botError: string | null = null;

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Initialize Discord bot
  initializeDiscordBot();

  // API endpoint to get bot status
  app.get("/api/status", (req, res) => {
    res.json({
      status: botStatus,
      error: botError,
      guilds: discordClient?.guilds?.cache?.size || 0,
      username: discordClient?.user?.tag || null,
    });
  });

  // API endpoint to get bot invite link
  app.get("/api/invite", (req, res) => {
    if (!discordClient?.user) {
      res.json({ inviteUrl: null });
      return;
    }

    // Generate invite URL with required permissions
    const permissions = [
      "Administrator", // Full permissions for server building
    ].join(",");

    const clientId = discordClient.user.id;
    const inviteUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&permissions=8&scope=bot%20applications.commands`;

    res.json({ inviteUrl });
  });

  // API endpoint to get connected guilds
  app.get("/api/guilds", (req, res) => {
    if (!discordClient) {
      res.json({ guilds: [] });
      return;
    }

    const guilds = discordClient.guilds.cache.map((guild: any) => ({
      id: guild.id,
      name: guild.name,
      memberCount: guild.memberCount,
      icon: guild.iconURL(),
    }));

    res.json({ guilds });
  });

  return httpServer;
}

async function initializeDiscordBot() {
  botStatus = "connecting";

  try {
    discordClient = await createDiscordBot();
    botStatus = "online";
    console.log("Discord bot initialized successfully");
  } catch (error) {
    botStatus = "error";
    botError = error instanceof Error ? error.message : "Unknown error";
    console.error("Failed to initialize Discord bot:", error);
  }
}
